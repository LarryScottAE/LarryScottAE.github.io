from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
OUT='/mnt/user-data/outputs/SierpinskiWorkbench-TestSummary-2026-11-07-Mac.pdf'
BLUE=colors.HexColor('#2E5AA8')
body=ParagraphStyle('b',fontName='Helvetica',fontSize=9.5,leading=12.5,spaceAfter=4)
cell=ParagraphStyle('c',parent=body,fontSize=8.5,leading=10.5,spaceAfter=0)
cellb=ParagraphStyle('cb',parent=cell,fontName='Helvetica-Bold')
h1=ParagraphStyle('h1',fontName='Helvetica-Bold',fontSize=16,leading=20,textColor=BLUE,spaceAfter=4)
h2=ParagraphStyle('h2',fontName='Helvetica-Bold',fontSize=11.5,leading=15,textColor=BLUE,spaceBefore=8,spaceAfter=3,keepWithNext=1)
bl=ParagraphStyle('bl',parent=body,leftIndent=12,bulletIndent=2,spaceAfter=2)
st=[]
P=lambda t,s=body: st.append(Paragraph(t,s))
def B(*xs):
    for x in xs: st.append(Paragraph(x,bl,bulletText='\u2022'))
def T(rows,w):
    d=[[Paragraph(c,cellb if r==0 else cell) for c in row] for r,row in enumerate(rows)]
    t=Table(d,colWidths=w,repeatRows=1)
    t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.4,colors.HexColor('#B8C2D6')),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#F2F5FB')),('VALIGN',(0,0),(-1,-1),'TOP')]))
    st.append(t); st.append(Spacer(1,6))

P('Sierpinski Workbench 2.0 for Windows and Mac',h1)
P('Handover summary - November 7, 2026 (evening): Windows finished, Mac builds next. Sierra Digital Audio (Larry Scott). '
  'Start the Mac chat by uploading this summary and SierpinskiWorkbenchV2.0-Workbench.zip.')
P('1. Where things stand',h2)
B('<b>Windows: complete.</b> Quick checks, installer Rounds 6 and 8 passed on the XL+. setupSierpinskiWorkbench_PC-V2.0.exe builds with InnoSetup\\Build-Installer.cmd and installs license.txt, ThirdPartyNotices.txt and SierpinskiWorkbenchHelp.pdf in C:\\Program Files\\Sierpinski Workbench; the Help tile opens the PDF.',
  '<b>Latest code:</b> SierpinskiWorkbenchV2.0-Workbench.zip (top folder SierpinskiWorkbenchV2.0; no bin / obj / .vs). Rebuilt and installed on the PC.',
  '<b>Help:</b> SierpinskiWorkbenchHelp.pdf (37 pages, current). Build files in SierpinskiWorkbench-HelpSource.zip (build_help.py, functions.tsv, img). Screenshots in SierpinskiWorkbench-HelpScreenshots.zip.',
  '<b>Server:</b> upload.php and share.json live and tested in /var/www/sierradigitalaudio/sierpinski/ (see the earlier summary).')
P('2. Changed in this session',h2)
T([['Area','Change'],
   ['Version history','SierpinskiVersionHistory.txt cut from 445 to 43 lines: only the major enhancements since AxeFXIIControl 1.0, plus a short 1.0 paragraph. No builds / phases.'],
   ['Preset count','Main window: "385 shown - 176 of 768 read from your unit" (counts only presets read from the unit, like the Presets banner).'],
   ['Preset Volume','Hidden on the Axe-Fx III, FM9 and FM3 also right after a Model change with no unit connected.'],
   ['Build-Installer.cmd','Before building, shows the InnoSetup\\SierpinskiWorkbenchHelp.pdf date / time / size and asks "Is this the LATEST ...?" (Y builds, N stops); if missing, asks whether to build without it.'],
   ['Help PDF','Upgrade text (import on first start; installer only offers to remove AxeFXIIControl); Preset Volume is Axe-Fx II only; sharing "to help us improve future releases", the only internet activity; thank-you / priority-support code removed everywhere.'],
   ['Sharing','Decided: no thank-you code and no priority-support offer (removed in the licensing chat). Code and license.txt already match.']],
  [1.35*inch,5.15*inch])
P('3. Testing this session (PC, XL+)',h2)
T([['Check','Result'],
   ['Sync dialog - Not now','Status line, version history, Setup reminder: pass.'],
   ['Presets window','Type, Used in, My notes, Edit Notes, note search: pass.'],
   ['Show filters','Amp showcase / Effects / Artist / Utility / Yours: pass (Yours = 495 Santana-Pete). Changing Show sends nothing (MIDI Log test).'],
   ['Model = FM9, unit off','Amp column, shaded AMP? guesses, tooltip: pass. The "Axe-Fx III version" line shows only on the 55 FM9 slots whose name differs (e.g. 079) - 027 correctly has none.'],
   ['Round 6 installer','Builds and installs; no AxeFXIIControl page (not installed): pass.'],
   ['Round 7 import','Skipped by Larry.'],
   ['Round 8','License shown, files installed, Help tile, new version history: pass. sha256.bat: run when the website is updated.'],
   ['Memory check','Skipped for now.']],
  [1.6*inch,4.9*inch])
P('4. Next steps, in order',h2)
B('<b>Mac builds (several hours):</b> copy the project to the M4 Mac mini, run bash Mac/build-mac-app.sh for Apple Silicon and Intel, producing setupSierpinskiWorkbench_Mac-AppleSilicon-V2.0.zip and setupSierpinskiWorkbench_Mac-Intel-V2.0.zip. Put SierpinskiWorkbenchHelp.pdf in each. Detailed step-by-step instructions for every Mac step.',
  '<b>Mac test</b> with the XL+: connect, Sync dialog, Presets, Setlists / Perform, Stage Monitor, Foot Control, Help; unsigned-app first start (quarantine removal or System Settings override, as in the help).',
  '<b>Release:</b> setupSierpinskiWorkbench_PC-V2.0.exe and the two Mac zips to GitHub downloads; SHA-256 for each (sha256.bat / shasum -a 256); sierpinski.html and homepage update (remove "New version next week", turn the installer buttons back on); short privacy page for the shared report.')
P('5. Open items',h2)
B('Foot Control: check that learned rows show again when the FCB1010 is connected (SierpinskiWorkbenchFootController.xml is 4 KB).',
  'Gen 3 (Axe-Fx III / FM9 / FM3): sharing and upload end to end, blocks reading, model IDs and newer block IDs need a beta tester - Appendix C.',
  'Help screenshots for Gen 3 (main window with the new Amp / Blocks / Used in columns, Presets window on Gen 3) still show an earlier build - retake when convenient.',
  'Server housekeeping after the release: Ubuntu updates and the 24.04 upgrade, carefully; sudo reboot, not Stop / Start.')
P('6. Working style',h2)
P('One task at a time; screenshot requests marked with red circles; "batch:" queues and "commit" builds; tell Larry before long steps; '
  'prepare the help PDF before a chat with screenshots closes; complete project zips named ...-Workbench.zip; detailed steps for Mac tasks.')
SimpleDocTemplate(OUT,pagesize=letter,leftMargin=inch,rightMargin=inch,topMargin=0.8*inch,bottomMargin=0.8*inch,title='Sierpinski Workbench handover 2026-11-07 Mac').build(st)
print('ok')
