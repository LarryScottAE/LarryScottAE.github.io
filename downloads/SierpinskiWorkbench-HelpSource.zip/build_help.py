# Builds SierpinskiWorkbenchHelp.pdf - Sierpinski Workbench 2.0 help (Sierra Digital Audio).
import os
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Image, Table,
                                TableStyle, KeepTogether, PageBreak, CondPageBreak)
from reportlab.platypus.tableofcontents import TableOfContents
from PIL import Image as PILImage

HERE = os.path.dirname(os.path.abspath(__file__))
IMG = os.path.join(HERE, 'img')
OUT = '/mnt/user-data/outputs/SierpinskiWorkbenchHelp.pdf'

BLUE = colors.HexColor('#2E5AA8')
GREY = colors.HexColor('#666666')
LIGHT = colors.HexColor('#F2F5FB')
BETA_BG = colors.HexColor('#FFF8E6')
BETA_BORDER = colors.HexColor('#E0A526')

body = ParagraphStyle('body', fontName='Helvetica', fontSize=10, leading=13.6, spaceAfter=6)
small = ParagraphStyle('small', parent=body, fontSize=8.5, leading=11)
caption = ParagraphStyle('caption', parent=body, fontName='Helvetica-Oblique', fontSize=8.5, textColor=GREY,
                         alignment=TA_CENTER, spaceBefore=2, spaceAfter=10)
title = ParagraphStyle('title', fontName='Helvetica-Bold', fontSize=24, leading=29, textColor=BLUE)
h1 = ParagraphStyle('h1', fontName='Helvetica-Bold', fontSize=15, leading=19, textColor=BLUE, spaceBefore=12, spaceAfter=6, keepWithNext=1)
h2 = ParagraphStyle('h2', fontName='Helvetica-Bold', fontSize=11.5, leading=15, textColor=BLUE, spaceBefore=8, spaceAfter=4, keepWithNext=1)
bullet = ParagraphStyle('bullet', parent=body, leftIndent=14, bulletIndent=3, spaceAfter=3)
step = ParagraphStyle('step', parent=body, leftIndent=18, bulletIndent=2, spaceAfter=3)
cell = ParagraphStyle('cell', parent=body, fontSize=8.5, leading=10.5, spaceAfter=0)
cellb = ParagraphStyle('cellb', parent=cell, fontName='Helvetica-Bold')
toc1 = ParagraphStyle('toc1', parent=body, fontSize=10, leading=14, leftIndent=8)
toc2 = ParagraphStyle('toc2', parent=body, fontSize=9, leading=12, leftIndent=24, textColor=GREY)

story = []


def P(t, s=body):
    story.append(Paragraph(t, s))


_n = [0]


def H1(t):
    story.append(CondPageBreak(1.6 * inch))
    p = Paragraph(t, h1)
    _n[0] += 1
    p._toc = (0, t, 'h%d' % _n[0])
    story.append(p)


def H2(t):
    story.append(CondPageBreak(1.1 * inch))
    p = Paragraph(t, h2)
    _n[0] += 1
    p._toc = (1, t, 'h%d' % _n[0])
    story.append(p)


def B(*items):
    for t in items:
        story.append(Paragraph(t, bullet, bulletText='\u2022'))


def S(*items):
    for i, t in enumerate(items, 1):
        story.append(Paragraph(t, step, bulletText=str(i) + '.'))


def pic(name, cap, max_h=4.6 * inch, max_w=6.5 * inch):
    path = os.path.join(IMG, name + '.png')
    w, h = PILImage.open(path).size
    scale = min(max_w / w, max_h / h)
    im = Image(path, width=w * scale, height=h * scale)
    im.hAlign = 'CENTER'
    story.append(KeepTogether([Spacer(1, 4), im, Paragraph(cap, caption)]))


def box(title_text, lines, bg=LIGHT, border=BLUE):
    inner = [Paragraph('<b>' + title_text + '</b>', ParagraphStyle('bt', parent=body, textColor=border if border != BLUE else BLUE))]
    for t in lines:
        inner.append(Paragraph(t, body))
    t = Table([[inner]], colWidths=[6.5 * inch])
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), bg), ('BOX', (0, 0), (-1, -1), 1, border),
                           ('LEFTPADDING', (0, 0), (-1, -1), 10), ('RIGHTPADDING', (0, 0), (-1, -1), 10),
                           ('TOPPADDING', (0, 0), (-1, -1), 7), ('BOTTOMPADDING', (0, 0), (-1, -1), 7)]))
    story.append(Spacer(1, 4))
    story.append(t)
    story.append(Spacer(1, 8))


def table(rows, widths, header=True):
    data = [[Paragraph(str(c), cellb if (header and r == 0) else cell) for c in row] for r, row in enumerate(rows)]
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
    style = [('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#B8C2D6')), ('VALIGN', (0, 0), (-1, -1), 'TOP'),
             ('LEFTPADDING', (0, 0), (-1, -1), 4), ('RIGHTPADDING', (0, 0), (-1, -1), 4),
             ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 3)]
    if header:
        style.append(('BACKGROUND', (0, 0), (-1, 0), LIGHT))
    t.setStyle(TableStyle(style))
    story.append(t)
    story.append(Spacer(1, 8))


class HelpDoc(BaseDocTemplate):
    def __init__(self, fn):
        super().__init__(fn, pagesize=letter, leftMargin=inch, rightMargin=inch, topMargin=0.8 * inch,
                         bottomMargin=0.85 * inch, title='Sierpinski Workbench 2.0 Help',
                         author='Sierra Digital Audio', subject='Sierpinski Workbench 2.0 for Windows and Mac')
        frame = Frame(self.leftMargin, self.bottomMargin, self.width, self.height, id='f')
        self.addPageTemplates([PageTemplate(id='p', frames=[frame], onPage=self.footer)])

    def footer(self, canv, doc):
        canv.saveState()
        canv.setFont('Helvetica', 8)
        canv.setFillColor(GREY)
        canv.drawString(inch, 0.5 * inch, 'Sierpinski Workbench 2.0 Help - Sierra Digital Audio - www.SierraDigitalAudio.com')
        canv.drawRightString(letter[0] - inch, 0.5 * inch, 'Page %d' % doc.page)
        canv.restoreState()

    def afterFlowable(self, f):
        if hasattr(f, '_toc'):
            level, text, key = f._toc
            self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(text, key, level=level, closed=level > 0)
            if level == 0:
                self.notify('TOCEntry', (level, text, self.page, key))


# ============================================================================ cover
logo = Image(os.path.join(IMG, 'logo.png'), width=1.35 * inch, height=1.35 * inch * 1588 / 1932)
cover = Table([[logo, Paragraph('Sierpinski Workbench<br/>Version 2.0 for Windows and Mac', title)]],
              colWidths=[1.6 * inch, 4.9 * inch])
cover.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'MIDDLE')]))
story.append(cover)
story.append(Spacer(1, 10))
P('Sierra Digital Audio - www.SierraDigitalAudio.com - November 2026')
P('Sierpinski Workbench is a computer control screen for the Fractal Audio <b>Axe-Fx II, XL and XL+</b>, and - as a beta - the '
  '<b>Axe-Fx III, FM9 and FM3</b>. It adds what the units themselves don\'t have: setlists, songs and sections, a full-screen '
  'Perform view and a Stage Monitor for a second screen or TV, foot-controller support, a searchable local preset list, a scene '
  'matrix and - for the Axe-Fx II - every front-panel function in one searchable, numbered list with step-by-step button '
  'instructions and, where possible, a MIDI control that does it for you.')
P('<i>Version 2.0 is a complete rebuild that runs on Windows and on the Mac (Apple Silicon and Intel). Sierpinski Workbench was '
  'called Axe-Fx II Workbench (AxeFXIIControl) up to version 1.0. It is the desktop companion to the Sierpinski VST3 plugin.</i>')
box('Gen 3 Beta - Axe-Fx III, FM9 and FM3', [
    'Support for the Axe-Fx III, FM9 and FM3 is a <b>beta</b>: it is built from Fractal\'s published documents and is being '
    'confirmed by beta testers. See <b>Axe-Fx III, FM9 and FM3 (beta)</b> for what works today, and <b>Appendix C</b> for the '
    'beta-tester checklist and the built-in self-test.'], bg=BETA_BG, border=BETA_BORDER)
P('<b>Contents</b>', h2)
toc = TableOfContents()
toc.levelStyles = [toc1, toc2]
story.append(toc)
story.append(PageBreak())

# ============================================================================ 1. install
H1('1. Installing and the first start')
H2('Downloads')
table([['Computer', 'Download'],
       ['Windows 10 / 11', 'setupSierpinskiWorkbench_PC-V2.0.exe - the installer'],
       ['Mac with Apple Silicon (M1 - M4 ...)', 'setupSierpinskiWorkbench_Mac-AppleSilicon-V2.0.zip'],
       ['Mac with an Intel processor', 'setupSierpinskiWorkbench_Mac-Intel-V2.0.zip']],
      [2.4 * inch, 4.1 * inch])
P('Each download has a SHA-256 checksum on the website, so you can check the file arrived intact. On Windows, also install '
  'Fractal Audio\'s USB driver for your unit (fractalaudio.com/support) before connecting by USB.')
H2('Upgrading from AxeFXIIControl or an earlier Workbench')
P('On its first start on Windows, Sierpinski Workbench copies your setlists, setlist notes, Foot Control settings and profiles, '
  'settings and preset list from an earlier Workbench or from AxeFXIIControl (with the new file names). If AxeFXIIControl is still '
  'installed, the installer offers to remove it - both programs would want the same MIDI ports. Nothing is moved or deleted: the '
  'old files stay where they were as a backup, and a file that already exists in Sierpinski Workbench is never replaced.')
H2('Where your files are kept - and what to back up')
P('Everything Sierpinski Workbench keeps is in one folder:')
B('<b>Windows:</b> %APPDATA%\\Sierra Digital Audio\\Sierpinski Workbench - open it by typing that line into the File Explorer '
  'address bar, or from a Command Prompt: <font face="Courier">explorer "%APPDATA%\\Sierra Digital Audio\\Sierpinski Workbench"</font>',
  '<b>Mac:</b> ~/Library/Application Support/Sierra Digital Audio/Sierpinski Workbench (in Finder: Go > Go to Folder...).')
P('Copy these somewhere safe now and then: <b>Workbench.settings.json</b> (settings), <b>PresetList.json</b> (the Axe-Fx II preset '
  'list; the Axe-Fx III, FM9 and FM3 each have their own, e.g. PresetList-FM9.json), <b>SierpinskiWorkbenchSetlists.xml</b> and '
  '<b>setlistnotes.txt</b> (setlists), <b>SierpinskiWorkbenchFootController.xml</b> and the <b>FootProfiles</b> folder (Foot Control).')
pic('26-Settings-folder', 'The settings folder on Windows.', max_h=2.6 * inch)
H2('The first start')
P('The first time Sierpinski Workbench starts, it takes you through three steps, in this order:')
pic('27-Sync-dialog', 'The first-start Sync window on an Axe-Fx II XL+. On an Axe-Fx III, FM9 or FM3 it also offers the optional Share box (section 13).', max_h=4.0 * inch)
S('<b>Sync your presets.</b> As soon as your unit is connected, a <b>Sync</b> window explains that a full preset sync is needed '
  'once: the Workbench starts with Fractal\'s factory presets for your unit, which probably don\'t match yours (and Fractal '
  'changes its factory presets with firmware updates). <b>SYNC NOW</b> reads every preset from your unit - about 10-15 '
  'minutes - and the list fills in as it reads. <b>Not now</b> keeps the factory list for now and asks again at the next start. '
  'STORE any unsaved edits first: the sync loads each preset in turn, then goes back to the one you were on.',
  '<b>Version history.</b> What\'s new in this version (switch it off in the window, or in Options).',
  '<b>Setup.</b> A short checklist that makes sure the Workbench and your unit use the same MIDI settings - see section 2.')
P('If no unit has connected after about 20 seconds (it\'s switched off, the USB cable or driver is missing, or the wrong MIDI '
  'port is chosen), Setup opens first, because its step 1 helps you connect. The Sync window then appears as soon as the unit '
  'connects. On later starts you only see the version history (if it is switched on) and, while Setup isn\'t finished, a '
  'reminder on the status line.')

# ============================================================================ 2. setup
H1('2. Setup')
P('Some of the Workbench\'s controls - the volume sliders, the controller knobs and the looper buttons - only work when the '
  'Workbench and your unit use the same MIDI numbers, and Fractal doesn\'t provide a way to ask the unit for them. Setup checks '
  'them with you, once, step by step. The bold note near the top reminds you to read your own presets (step 8). Each step '
  'ticks itself when the Workbench can tell it works, or you tick it by hand. Open Setup again at any time from the menu '
  'panel - for example after a firmware update, a reset, or new MIDI gear.')
pic('04a-Setup-top', 'Setup on an Axe-Fx II XL+: why Setup is needed, and steps 1-4.', max_h=5.0 * inch)
pic('04b-Setup-bottom', 'Steps 4-8. Step 8 ticks itself once every preset has been read from the unit.', max_h=5.0 * inch)
table([['Step', 'What it checks'],
       ['1. Connect', 'MIDI Out and MIDI In are the unit\'s ports, and "Connected" turns green (Refresh MIDI Lists, Model, Detect).'],
       ['2. MIDI settings on the unit', 'MIDI channel, Program Change on, no mapping, PC offset 0 and SEND REALTIME SYSEX = ALL. '
        'Run Test MIDI: it checks that the unit follows Program Change.'],
       ['3. Tuner readout and tempo light', 'The Tempo panel\'s light flashes in time - this step ticks itself.'],
       ['4. Volume sliders', 'Main Output, Output 2 and (Axe-Fx II) Preset Volume change the level. If not: Fix volumes... (the MIDI CC troubleshooting window).'],
       ['5. Controller knobs', 'The Ctrl tab\'s Input knob works (and Ext 1-5 if you use External Controllers).'],
       ['6. Looper buttons (optional)', 'Rec, Play... work in a preset with a Looper block.'],
       ['7. Axe-Edit on the same computer', 'How the Workbench and Axe-Edit share the unit - see section 12.'],
       ['8. Read your presets', 'Resync All reads every preset from the unit (10-15 minutes). Ticks itself when every preset has been read.']],
      [1.9 * inch, 4.6 * inch])
H2('Prerequisites on the Axe-Fx II (step 2)')
P('The Workbench changes presets with Bank Select + Program Change. The Axe-Fx II only follows them when these system '
  'settings are right. Press <b>I/O</b>, then <b>PAGE &gt;</b> to the <b>MIDI</b> tab, and use NAV / VALUE to set:')
B('MIDI CHANNEL = the Workbench\'s Channel box (or OMNI)', 'PROG CHANGE = ON', 'MAPPING MODE = NONE',
  'MIDI PC OFFSET = 0 (or the same offset in Options)', 'SEND REALTIME SYSEX = ALL (the tuner readout and tempo light)')
P('Press RECALL when done - these settings need no STORE. Then click <b>Run Test MIDI</b>. If the unit doesn\'t follow, Test MIDI '
  'tries channels 1-16, sets the Channel box to the one that works, and loads your original preset again.')

# ============================================================================ 3. main window
H1('3. The main window')
pic('01-Main-window', 'The main window (Gray style) connected to an Axe-Fx II XL+.', max_h=4.6 * inch)
P('The main window has the <b>Fractal Device</b> panel (top left), the <b>menu</b> (bottom left), the loaded <b>preset</b>, '
  '<b>Scenes</b>, <b>Blocks</b> and the <b>preset list</b> in the middle, and the live controls on the right. Hover over any '
  'button for a hint.')
H2('Fractal Device panel')
B('<b>MIDI Out / MIDI In:</b> the unit\'s ports (usually "AXE-FX II MIDI Out / In"). The Workbench picks them by itself the first time; '
  '<b>Refresh MIDI Lists</b> reads the ports again (for example after plugging in a MIDI interface).',
  '<b>Model</b> and <b>Detect:</b> the unit model; Detect tries all six models. <b>Channel</b> and <b>Test MIDI</b> (see Setup step 2).',
  '"Connected - firmware 31.03" turns green when the unit answers. If the unit is off, the Workbench keeps trying.')
H2('The loaded preset, scenes and blocks')
B('The preset number, name, scene, bank and PC. The arrows step to the next / previous preset (also Page Down / Page Up). '
  '<b>Refresh</b> reads the unit again - press it after changing something in Axe-Edit.',
  '<b>EDITED</b> lights when the preset has unsaved changes; <b>CPU</b> shows the unit\'s load.',
  '<b>Scenes:</b> 8 buttons; the lit one follows scene changes made on the unit.',
  '<b>Blocks:</b> every block in the preset. Click to engage / bypass; right-click to switch X / Y (on Gen 3 units: the next channel A-D). '
  'Changes are not saved until you STORE the preset on the unit.')
H2('The preset list and Show')
P('The list under the blocks holds every preset in the local preset list (section 4). Click a row to load it (with <b>Load on select</b> '
  'ticked), or use the green arrow. The <b>Show</b> list chooses what is listed: All presets, Favourites (click a row\'s star), '
  'Recent (this session), or a preset <b>type</b> - Amp showcase, Effects, Artist, Utility, or <b>Yours</b> (slots holding presets of your own). '
  '<b>Search Presets</b> (bottom right) finds names, amps, cabs, drives, blocks, notes, types and setlist names - all words must match.')
H2('Controls, volumes, tempo and tuner (right)')
B('<b>Controls panel:</b> tabs for the preset\'s Amp, Cab, Drive, Delay, Reverb and Chorus blocks with their main knobs, and <b>Ctrl</b> '
  '(Input and External Controllers 1-5). It opens on the first tab - Amp on the Axe-Fx II, Channels on Gen 3 units. Double-click a knob to reset it.',
  '<b>Preset Volume</b> (Axe-Fx II, XL and XL+ only), <b>Main Output Volume</b> and <b>Output 2 Volume</b>. The volume sliders click-stop in steps (5 % by default - Options). '
  'Output 2 only changes what is plugged into OUTPUT 2.',
  '<b>Tempo:</b> Tap, or type a BPM and Set Tempo. The red light flashes with the unit\'s tempo.',
  '<b>Tuner:</b> on / off and a live readout.')
H2('Looper')
pic('02-Main-looper', 'The Looper panel says whether the preset has a Looper block; the lights show what the Workbench last sent.', max_h=3.6 * inch)
B('The looper buttons need a <b>Looper block</b> in the preset - the panel says "Looper found in preset" (green) or "No looper found" (red, buttons disabled).',
  '<b>Rec, Play, Dub, Rev, Half, Undo</b> work like the unit\'s looper. <b>Once</b> plays the loop one time and its light goes off by itself (timed from Rec to Play).',
  '<b>On/Off</b> engages or bypasses the Looper block, exactly like its Blocks tile. Turning it off stops what the Workbench started and puts every looper light out.',
  'The <b>?</b> button explains every looper button.')
H2('Status line, MIDI out and Web lights')
P('The status line at the bottom says what just happened. <b>MIDI out</b> flashes when MIDI is sent to the unit. <b>Web</b> is '
  'green when sierradigitalaudio.com can be reached - it is only used for the optional shared factory preset report on Gen 3 '
  'units (section 13), and stays grey ("not needed") otherwise.')
H2('Styles')
P('The <b>Style</b> box (top right) switches between four looks - Light, Gray, Dark and Blue. Every button has a filled '
  'background so it reads as a button; the main action buttons are blue.')

# ============================================================================ 4. presets
H1('4. Presets - the local preset list')
P('The Workbench keeps your presets\' names (plus Amp 1, Amp 2, Cab 1, Drive 1 and the blocks used) on this computer, so it can '
  'show, search and drag presets instantly. It starts with Fractal\'s factory presets for your unit, marked "factory default" '
  'in the Last read column, until you read your own. The list is a snapshot: if you change presets in Axe-Edit or on the unit, '
  'resync them. Presets the Workbench loads while you play are checked and updated automatically.')
pic('06-Presets', 'The Presets window. The banner says how many presets have been read from your unit.', max_h=4.4 * inch)
H2('Columns')
table([['Column', 'What it shows'],
       ['Star', 'Favourites - click to add or remove; Show > Favourites lists them.'],
       ['No., Bank, Name', 'The preset number (000-767 on the XL / XL+), its bank and program, and its name.'],
       ['Amp 1, Amp 2, Cab 1, Drive 1', 'The block types read from the unit (Axe-Fx II).'],
       ['Blocks', 'The blocks in the preset, in Fractal\'s short codes - AMP1 CAB1 CHO1 DLY1 ...'],
       ['Type', 'What Fractal put in the factory slot: Amp showcase, Effects, Artist or Utility - or <b>Yours</b> when the slot holds a preset of your own.'],
       ['Used in', 'The setlists and songs that load this preset.'],
       ['My notes', 'Your own notes - select a preset and press <b>Edit Notes...</b>. Notes are kept when presets are read again, and Search finds them.'],
       ['Last read', 'When the preset was read from your unit, or "factory default".']],
      [1.8 * inch, 4.7 * inch])
H2('Reading presets')
B('<b>Resync All</b> reads every preset (10-15 minutes - each preset is loaded in turn). STORE unsaved edits first; Output 1 is muted while reading '
  '(set the volume to restore afterwards in the box below the buttons).',
  '<b>Resync Selected</b> reads only the highlighted presets (click a row first; Ctrl / Shift + click selects several); <b>Resync Range</b> reads a from-to range.',
  '<b>Cancel</b> stops after the current preset and asks whether to keep the presets read so far:')
pic('07-Presets-cancel', 'Keep merges what was read with the saved list; Disregard leaves the list exactly as it was.', max_h=1.9 * inch)
B('<b>Load Selected</b> (or double-click) loads a preset on the unit. The orange bar only marks the loaded preset - click a row to select it.')
P('<b>Demo Setlist.</b> When the first full read finishes, a Demo Setlist with a few songs is created (only if you have no setlists yet). Edit it, replace it or delete it.')

# ============================================================================ 5. setlists
H1('5. Setlists, songs and sections')
P('The Axe-Fx II has no setlists of its own - only presets and their 8 scenes. Sierpinski Workbench gives it the same idea Fractal '
  'added to the Axe-Fx III, run from your computer, with no limits:')
B('A <b>section</b> is one sound in a song - Intro, Verse, Chorus, Solo ... Each section loads a scene (1-8), and can load a preset of its own.',
  'A <b>song</b> is a name, a preset, a list of sections, an optional tempo, a stage banner and your notes.',
  'A <b>setlist</b> is a list of songs in playing order. A song can be in a setlist more than once.')
pic('08-Setlists', 'The Setlists window: 1. Setlists, 2. Songs of the selected setlist, 3. All presets.', max_h=3.7 * inch)
H2('Quick start')
S('Open <b>Setlists</b>, press <b>New Setlist</b> and name it (e.g. "Friday at the Grange").',
  'Drag presets from list 3 into list 2 (Ctrl / Shift selects several). Each becomes a song with one section ("Main", Scene 1).',
  'Double-click a song to name its sections, set a tempo, a stage banner and notes.',
  'Drag songs up and down (or Move Up / Move Down) to put them in playing order.',
  '<b>Notes...</b> holds notes for the whole setlist (venue, start time, tunings). <b>Print...</b> prints it in large type; <b>Export...</b> writes a text or CSV file for the band.',
  'Press <b>Perform &gt;&gt;</b> and play. Esc goes back.')
H2('Editing a song')
pic('09-Song-editor', 'Edit Song: preset, tempo, stage banner, sections (each with a scene and an optional own preset) and notes.', max_h=4.2 * inch)
B('<b>Try It</b> loads the preset; <b>Use Current Preset + Scene</b> copies what is loaded on the unit.',
  '<b>Set the tempo to</b> sets the global tempo each time the song loads (works best when the preset\'s TEMPO TO USE is GLOBAL).',
  '<b>Stage banner</b> - a short warning shown big on the Perform and Stage Monitor screens, e.g. DROP D or CAPO 2.',
  '<b>Sections:</b> Add Section, move up / down, remove; <b>Try</b> plays a section. Leave Own preset blank to use the song\'s preset.',
  'Hold Ctrl while dropping presets ON a song to add them to it as sections, each loading its own preset.')
P('Everything is saved at once in SierpinskiWorkbenchSetlists.xml. Setlists store preset <b>numbers</b>: if you switch the '
  'Workbench between unit models, a setlist built on one unit shows the other unit\'s presets in those slots.')

# ============================================================================ 6. perform
H1('6. Perform')
pic('10-Perform', 'Perform: the song, its preset, section buttons, notes and the setlist on the right.', max_h=4.0 * inch)
B('Click a section button, or use <b>&lt;&lt; Song</b>, <b>&lt; Section</b>, <b>Section &gt;</b>, <b>Song &gt;&gt;</b>, or click a song in the list.',
  '<b>Keys</b> (also a USB page-turner pedal): Right / Space = next section, Left = previous section, Down / Page Down = next song, '
  'Up / Page Up = previous song, 1-8 = section, Enter = reload the song, Esc = exit.',
  'Next section on the last section moves on to the next song. At the end of the setlist it stops ("Last song of the set").',
  'When you change scene on the unit itself, the lit section follows it. The computer is kept awake while Perform is open, and closing it asks first.',
  'The song\'s stage banner (e.g. DROP D) shows across the top.')

# ============================================================================ 7. stage monitor
H1('7. Stage Monitor')
P('Stage Monitor opens a big, full-screen display on a second monitor or TV, readable from about 10 feet, plus a control window '
  'on the computer. It needs a setlist with at least one song.')
pic('11-StageMonitor-song', 'Song view: setlist and song number, the stage banner, song, section, what\'s next, preset, scene and tempo, notes, and a bottom strip with the tempo light, block tiles and tuner.', max_h=3.6 * inch)
pic('12-StageMonitor-setlist', 'Setlist view: every song with its preset, the current one highlighted.', max_h=3.6 * inch)
pic('13-StageMonitor-control', 'The control window on the computer.', max_h=4.4 * inch)
B('<b>Display:</b> pick the screen (Identify Screens shows a number on each). Set Windows to Extend (Win+P). With one screen the monitor opens as a preview window.',
  '<b>Look:</b> text size, dark stage theme or high contrast (daylight), TV safe margin, burn-in protection for OLED TVs, the tuner strip, and a test pattern - walk to your playing position and check every line.',
  '<b>Show:</b> block tiles, song notes, set timer and clock, how long the setlist overview stays open.',
  '<b>During the gig:</b> a message to the stage (shown in an amber bar), the set timer, Setlist View, and Reset Played Songs.',
  '<b>Keys on the monitor:</b> L = setlist view, S = overview, Up / Down = cursor, Enter = Go, Esc = close. Move the mouse to the top right for a Close button.',
  '<b>TVs:</b> use the TV\'s PC or Game mode (no cropping, no picture delay) and turn off its eco auto power-off. About 1 inch of letter height per 10 feet is the minimum; a 32" screen is the sweet spot for 10 feet.')

# ============================================================================ 8. foot control
H1('8. Foot Control')
P('Foot Control lets a Behringer FCB1010, an MFC-101 or any MIDI pedal run the Workbench: songs and sections, the Stage Monitor, '
  'volumes, the tuner, tap tempo, scenes, presets, External Controllers, the looper and every block. Connect the pedal\'s MIDI OUT '
  'to a USB-MIDI interface on the computer and tick that interface under MIDI inputs.')
pic('14a-FootControl-learned', 'Foot Control with four FCB1010 switches learned (Program Change 0-3 on channel 2).', max_h=4.3 * inch)
B('Two lists: <b>Setlist navigation</b> and <b>Axe management</b>. Every function can have two triggers.',
  '<b>Learn:</b> press Learn on a function, then step on the switch. It records the device, channel and message (Program Change, '
  'Bank + Program Change, Note or CC). Tick <b>Learn next</b> to set up a whole pedalboard in one pass; Cancel Learn or Esc stops.',
  '<b>Main Output Volume up / down</b> move the slider one click-stop step (5 % by default).',
  '<b>Long press</b> (hold for 0.6 s) runs a second function - e.g. tap tempo normally, tuner when held. It needs a <b>momentary CC switch</b> '
  '(127 on press, 0 on release). Not all foot controllers support it - the stock FCB1010 may not (firmware such as UnO or EurekaPROM adds momentary switches).',
  '<b>Pedal range</b> and <b>Invert</b> adjust expression pedals. <b>Test</b> runs a function; <b>Clear</b> / <b>Clear All</b> remove assignments.',
  '<b>Also listen to the unit\'s MIDI In</b> (MFC-101 or a pedal on the unit, CC only). <b>Pass unmapped messages through</b> forwards anything you haven\'t assigned.',
  '<b>Save Profile / Load Profile</b> keep a setup per pedalboard (FootProfiles folder); <b>Load Template</b> gives a starting point.',
  'The switches work with the Foot Control window closed. The <b>FCB1010 Direct-Wiring Guide</b> explains plugging the FCB1010 straight into the Axe-Fx II as a backup without a computer.')
pic('14b-FootControl-note', 'The long-press note next to the Axe management tab.', max_h=3.6 * inch)

# ============================================================================ 9. scene matrix
H1('9. Scene Matrix')
pic('15-SceneMatrix', 'All 8 scenes of preset 004 against every block, read with Read Scenes.', max_h=3.8 * inch)
B('<b>Read Scenes</b> visits each scene, reads its blocks and goes back to the scene you were on. Raise <b>Wait per scene</b> for slow MIDI interfaces.',
  '<b>Click</b> a cell to go to that scene and engage / bypass the block. <b>Right-click</b> switches X / Y.',
  '<b>What X / Y means:</b> on the Axe-Fx II most blocks have two complete sets of settings, X and Y - like two channels (e.g. Amp X clean, Amp Y lead). '
  'Each scene chooses which one it uses. The Looper has no X / Y. (Gen 3 units have channels A-D instead.)',
  'The current scene\'s column follows changes made on the main screen or the unit. The other scenes need Read Scenes, because the unit can only report the loaded scene.',
  'Changes are edits: <b>How to STORE</b> explains saving the preset (STORE, ENTER, ENTER). Loading another preset throws them away.')

# ============================================================================ 10. settings
H1('10. Settings - every Axe-Fx II function')
P('The Settings window lists 99 Axe-Fx II functions from the Owner\'s Manual, numbered in order of how often players need them. '
  'Type in the search box (words or a number), pick a category, or tick <b>Only functions with a MIDI command</b>. Click a row for '
  'its description; double-click (or Enter) for the front-panel button steps and, where there is one, the MIDI control that does it '
  'for you. The full list is in Appendix B.')
pic('16-Settings', 'Settings with "tempo" typed in the search box.', max_h=3.9 * inch)
pic('17-Function-dialog', 'A function: the front-panel steps, a highlighted note, and the MIDI control.', max_h=4.1 * inch)

# ============================================================================ 11. cc map etc
H1('11. CC Map, MIDI CC troubleshooting, Controllers, MIDI Log and Options')
H2('What a MIDI CC is')
P('A MIDI <b>CC</b> (Control Change) message has a <b>number</b> - which control it is for - and a <b>value</b> from 0 to 127 - how much, '
  'or off (0) / on (127). The unit only reacts to a CC number its I/O &gt; CTRL page has given to that function.')
H2('CC Map')
pic('18-CCMap', 'CC Map: Your CC# in blue where it differs from the factory number (here Input Volume = 1).', max_h=4.3 * inch)
B('Type the CC number your unit uses (blank = NONE) and press Enter. Clashes - one number used for two functions - show in red in the Notes column.',
  '<b>Test</b> sends 127 or 0. The two volume increment / decrement functions <b>save the preset</b> on the unit - the Workbench asks first.',
  '<b>Read Block CCs From Unit</b> copies the bypass and X / Y CC numbers of the blocks in the loaded preset.',
  '<b>Reset All to Factory Defaults</b> undoes your own numbers - use it with care.')
H2('MIDI CC troubleshooting')
pic('05-Troubleshooter', 'MIDI CC troubleshooting: the knobs, sliders and looper buttons, the unit\'s CTRL line for each, the Workbench\'s number and a Test button.', max_h=4.3 * inch)
P('Fix one row at a time: either set the unit to the Workbench\'s number (I/O &gt; CTRL, the VALUE wheel), or type the unit\'s number into '
  '"Workbench CC#". Then click Test. A clash is shown in red as soon as the window opens. Before giving a line a new number, '
  '<b>scroll the whole CTRL list</b> - see section 14 for why.')
H2('Controllers')
pic('19-Controllers-MIDILog', 'External Controllers 1-12 beside the MIDI Log: Ext 4 sent CC 19 = 0, then 127.', max_h=3.2 * inch)
P('Twelve faders send External Controllers 1-12 (CC 16-27 by default). Drag, use the mouse wheel, click 0 or 127, or double-click for 0. '
  'They act on parameters that have a modifier with EXTRN 1-12 as the source.')
H2('MIDI Log')
pic('20-MIDILog-hidden', 'The MIDI Log with Status checks: Hidden - only your own messages are listed.', max_h=4.0 * inch)
P('Every message the Workbench sends and receives. The steady OUT / IN pairs are the <b>status check</b>: every 2.5 s (1.2 s on the '
  'Axe-Fx III, FM9 and FM3) the Workbench asks the unit for its CPU load, EDITED light, preset and scene, so the screen follows '
  'changes made on the unit. They are normal. <b>Status checks: Shown / Hidden</b> hides them (the checks still run). Also: Pause, '
  'Clear, Select All and Copy to Clipboard, and the Gen 3 Self-Test (Appendix C).')
H2('Options')
pic('21-Options', 'Options.', max_h=4.6 * inch)
B('<b>Scenes, block bypass and X / Y</b> sent as SysEx (recommended) or always as MIDI CC (uses the CC Map).',
  '<b>MIDI PC OFFSET</b> (the same as the unit\'s), <b>Wait for a SysEx reply</b> (raise it for slow 5-pin interfaces), <b>Show version history on startup</b>.',
  '<b>Axe-Edit:</b> where the editor is, and whether to explain the sharing before starting it.',
  '<b>Connected through:</b> detect from the port name, the unit\'s own USB port, or a USB-to-MIDI adapter; and <b>Keep the Workbench connected while Axe-Edit runs</b>.',
  '<b>Click-stop step</b> for the volume sliders (also Foot Control\'s volume up / down).')

# ============================================================================ 12. axe-edit
H1('12. Using Axe-Edit')
P('The <b>Axe-Edit</b> tile starts Fractal\'s editor (Axe-Edit for the Axe-Fx II; Axe-Edit III, FM9-Edit or FM3-Edit for Gen 3 units). '
  'What happens next depends on how the Workbench reaches the unit:')
B('<b>The unit\'s USB port, shared</b> (Windows 11 with Windows MIDI Services - the default when the port can be shared): both stay connected. '
  'While the editor is open the Workbench stops its regular status checks, so the editor isn\'t kept paused; <b>press Refresh</b> (or click '
  'back into the Workbench) to see changes made in the editor - for example a preset loaded in Axe-Edit. The editor may show '
  '"Communications paused" for a few seconds when the Workbench changes the preset; it resumes by itself.',
  '<b>One program at a time</b> (Windows 10, or with Keep connected unticked in Options): the Workbench closes its ports, greys out its live '
  'controls and says "Axe-Edit has the unit". When the editor closes it reconnects by itself.',
  '<b>A USB-to-MIDI adapter</b> on the unit\'s MIDI jacks for the Workbench: the editor uses USB and both run side by side.')
pic('03-Main-AxeEdit-handover', 'Hand-over: "Axe-Edit has the unit" and the live controls greyed while the editor is connected.', max_h=4.2 * inch)
P('STORE your edits in the editor, and if you renamed or changed presets, use Presets &gt; Resync Selected to update the local list. '
  'Don\'t read all presets while editing in the Fractal editor.')

# ============================================================================ 13. gen 3
H1('13. Axe-Fx III, FM9 and FM3 (beta)')
P('Choose the unit under <b>Model</b> (or press Detect). The screens adapt: the Controls panel shows <b>Channels</b> and <b>Ctrl</b>, '
  'blocks show their channel (A-D) and right-click steps to the next channel, and there is no Preset Volume slider (the Workbench can\'t set it on these units).')
pic('23-AxeFxIII', 'The main window with Model = Axe-Fx III (no unit connected). Taken with an earlier test build: the preset list now shows the unit\'s own factory presets with Amp, Blocks and Used in.', max_h=4.0 * inch)
H2('Connecting')
B('The Axe-Fx III and FM9 work over USB or a USB-to-MIDI adapter; the <b>FM3 needs a 5-pin MIDI interface</b> (it has no USB MIDI).',
  'On the unit open SETUP &gt; MIDI/Remote: MIDI channel = the Workbench\'s Channel box, Program Change on, no mapping, and '
  '<b>Send Realtime Sysex = ON</b> - Setup shows the exact steps for your unit.',
  'The tuner readout and tempo light need 5-pin MIDI (these units don\'t send them over USB). Tuner on / off and tap tempo work over any connection.',
  'These units can\'t report unsaved edits or their firmware number, and have no EDITED light - STORE before syncing or testing.')
pic('04c-Setup-FM9', 'Setup with Model = FM9: the steps for the FM9\'s own menus.', max_h=4.4 * inch)
H2('The preset list on Gen 3 units')
P('A new installation already contains Fractal\'s <b>384 factory presets</b> for your unit (names from the Fractal Audio wiki, based on '
  'Axe-Fx III firmware 28.05, FM9 firmware 9 and FM3 firmware 10), each with:')
B('<b>Amp:</b> the amp the factory preset is built on, from Fractal\'s factory preset notes.',
  '<b>Blocks:</b> until a preset is read from your unit, the blocks <b>expected</b> from the factory notes are shown <i>shaded with question marks</i> '
  '(e.g. AMP? CAB? DRV? DLY?). Once the preset has been loaded, or the first-start sync has run, the real blocks are shown in Fractal\'s short codes (AMP1 CAB1 DRV1 ...).',
  '<b>Type</b> (Amp showcase 000-127, Effects 128-345, Artist 346-380 - the "Gift of Tone" presets - and Utility 381-383), <b>Used in</b> and <b>My notes</b>.')
P('Gen 3 units report a preset\'s name and blocks, but not which amp or drive model a block uses - so after a sync, presets of your own show '
  'their blocks but no amp. Where an FM9 or FM3 factory preset is a different version from the Axe-Fx III\'s, its tooltip says the amp and expected '
  'blocks come from the Axe-Fx III version. The FM3 has one Amp and one Cab block (the III and FM9 have two), so many FM3 factory presets are simpler.')
pic('24-FM9', 'Model = FM9 (earlier test build - see above).', max_h=3.2 * inch)
pic('25-FM3', 'Model = FM3 (earlier test build - see above).', max_h=3.2 * inch)
H2('Sharing your factory preset list (optional)')
P('On an Axe-Fx III, FM9 or FM3, the first-start Sync window may offer a box - <b>unticked</b> unless you tick it - to share your unit\'s '
  'factory preset list with Sierra Digital Audio, <b>to help us improve future releases</b>: future versions of the Workbench can then '
  'show every user the real blocks of the factory presets from the start. This is the Workbench\'s only internet activity.')
B('<b>What is sent:</b> only the slots that still hold a Fractal factory preset - number, factory name and the blocks read from your unit - plus the unit model, '
  'the firmware number if you type it, and the date. <b>Show what will be sent</b> displays an example.',
  '<b>What is never sent:</b> your own presets or their names, your settings, setlists or notes, or anything about you or your computer.',
  '<b>How:</b> once, after the sync, to sierradigitalaudio.com. With no internet connection the report waits in the settings folder and is '
  'sent by itself later - the <b>Web</b> light (beside MIDI out) shows green when the site can be reached. About &gt; <b>Email the shared report</b> is the backup.',
  'Saying no changes nothing - the Workbench works exactly the same. Once enough reports have arrived for a unit, the Workbench stops asking.')

# ============================================================================ 14. axe-fx II tips
H1('14. Tips for the Axe-Fx II, XL and XL+')
P('Found while testing Sierpinski Workbench 2.0 on an Axe-Fx II XL+:')
B('<b>Set CC numbers with the VALUE wheel.</b> The CTRL page\'s Learn (ENTER, LEARNING) ignores CCs arriving over USB - tried from the Workbench and from a DAW, '
  'with single values, sweeps, 7-bit and 14-bit; the MIDI IN light blinks, and the unit acts on the same CCs normally. Learn most likely listens to '
  'the 5-pin MIDI IN only. Press EXIT to leave Learn mode. (The Workbench\'s MIDI CC troubleshooting window therefore has no Teach button for the Axe-Fx II.)',
  '<b>Two CTRL lines can share a CC number without warning.</b> On the test unit OUT1 VOLUME and DRIVE 2 BYP were both 50, so moving Main Output Volume toggled '
  'Drive 2. Before giving a line a new number, scroll the whole CTRL list. The Workbench shows clashes it knows about in red.',
  '<b>PEDAL1 on an EXT CTRL line</b> means the unit\'s PEDAL 1 jack controls it - MIDI can\'t (the Ctrl tab\'s Ext 1 knob won\'t move it).',
  '<b>The looper needs a Looper block</b> in the preset. A looper CC\'s value is its state (127 on, 0 off); ONCE held at 127 keeps looping, so it must be a press (127 then 0) - the Workbench does this for you.',
  '<b>With Axe-Edit open, press Refresh</b> to see its changes - the Workbench doesn\'t keep polling then.')

# ============================================================================ 15. troubleshooting
H1('15. Troubleshooting')
table([['Problem', 'What to check'],
       ['No MIDI devices / "could not open"', 'Install the Fractal USB driver, close Axe-Edit and Fractal-Bot (unless your PC shares ports - Appendix D), press Refresh MIDI Lists. '
        'Plug in and switch on MIDI gear before starting the Workbench.'],
       ['Connected, but presets don\'t change', 'Channel, PROG CHANGE = ON, MAPPING MODE = NONE and MIDI PC OFFSET (the same offset in Options). Run Test MIDI.'],
       ['A knob, slider or looper button does nothing', 'MIDI CC troubleshooting (Setup step 4, or the link under the sliders): the unit\'s CTRL number must match the Workbench\'s. '
        'The looper needs a Looper block; External Controllers need a modifier using them.'],
       ['No tuner readout / tempo light', 'SEND REALTIME SYSEX = ALL (Axe-Fx II) or Send Realtime Sysex = ON (Gen 3; 5-pin MIDI only).'],
       ['Blocks panel empty while connected', 'It says why: an empty preset, or no reply from the unit (check MIDI In; the MIDI Log shows what was sent and received).'],
       ['Axe-Edit shows "Communications paused"', 'Normal for a few seconds after the Workbench changes the preset; click it only if it stays paused.'],
       ['The Gen 3 preset list shows factory presets', 'Run the sync: Presets &gt; Resync All (tick Read blocks too to read the blocks).'],
       ['The shared report is waiting', 'The Web light is grey (no internet). It is sent by itself later - or use About &gt; Email the shared report.']],
      [2.1 * inch, 4.4 * inch])
P('See also the Troubleshooting category in the Settings window.')

# ============================================================================ Appendix A tutorial
story.append(PageBreak())
H1('Appendix A - Tutorial: a guided tour of the Workbench')
P('A hands-on walk through everything the Workbench does, in a sensible order. It takes about an hour; each part stands on its own. '
  'The examples use an Axe-Fx II XL+ and the Demo Setlist; your preset names will differ. STORE any edits on the unit before you begin.')

H2('A1. Connect and run Setup (10 minutes)')
S('Switch on the unit, connect it by USB and start the Workbench. "Connected" turns green in the Fractal Device panel.',
  'On the first start, the Sync window appears - choose <b>SYNC NOW</b> (10-15 minutes) or Not now. Then the version history and Setup open.',
  'In Setup, follow each step. In step 2 click <b>Run Test MIDI</b>; in step 4 move Main Output Volume while playing; in step 5 turn the Ctrl tab\'s Input knob.',
  'Click <b>Done</b>. The bottom of the window counts the steps done.')
H2('A2. Presets: browse, search and note (5 minutes)')
S('Click <b>Presets</b>. Look at the banner: it says how many presets have been read from your unit.',
  'Type <b>plexi</b> in Search - only matching presets stay. Clear it.',
  'Click a row, then <b>Edit Notes...</b> and type "great rhythm sound". Search for <b>rhythm</b> - the preset is found by its note.',
  'On the main window, set <b>Show</b> to <b>Amp showcase presets</b>, then <b>Yours (not factory)</b>, then All presets.',
  'Click a preset\'s star, then Show &gt; Favourites.')
H2('A3. Build a song and a setlist (10 minutes)')
S('Click <b>Setlists</b>, then <b>New Setlist</b>, and call it "My First Set".',
  'Drag three presets from list 3 into list 2.',
  'Double-click the first song. Name it, add sections - Verse (Scene 1), Chorus (Scene 2), Solo (Scene 3) - set the tempo to 120 and the stage banner to DROP D. Click OK.',
  'Drag the songs into the order you want, and click <b>Notes...</b> to add a line for the gig.')
H2('A4. Perform and the Stage Monitor (10 minutes)')
S('Click <b>Perform &gt;&gt;</b>. Press Right (or Space) to step through the sections, Down for the next song. The preset and scene change on the unit.',
  'With a second screen or TV connected, click <b>Stage Monitor</b>. The song, section and DROP D banner appear in big type.',
  'Press <b>L</b> on the monitor for the setlist view, L again to go back. Try the text size and the test pattern in the control window.',
  'Press Esc to close Perform; it asks first.')
H2('A5. Foot Control (10 minutes, with a MIDI pedal)')
S('Connect the pedal to a USB-MIDI interface and click <b>Foot Control</b>. Tick the interface under MIDI inputs.',
  'Click Learn on <b>Main Output Volume down 5%</b> and step on a switch; do the same for volume up, Next song and Previous song.',
  'Step on the switches: the volume slider moves one step per press; in Perform the songs change. Close the window - the switches keep working.',
  'Click <b>Save Profile...</b> to keep this setup.')
H2('A6. Live controls and the looper (5 minutes)')
S('Load a preset with a Looper block (the Looper panel says "Looper found in preset").',
  'Press <b>Rec</b>, play a phrase, press <b>Play</b>. Try Dub, Undo, Half and Rev. Press <b>Once</b>: the loop plays one pass and the light goes out.',
  'Click a Blocks tile to bypass a block, right-click it to switch X / Y. Press <b>Tap</b> a few times, then turn the tuner on and off.')
H2('A7. Scene Matrix and Settings (5 minutes)')
S('Click <b>Scene Matrix</b>, then <b>Read Scenes</b>. Every block\'s state appears for all 8 scenes.',
  'Click a cell to engage / bypass that block in that scene; right-click to switch X / Y. Load the preset again to throw the edits away.',
  'Click <b>Settings</b>, type <b>tempo</b>, and double-click "Tap tempo / set the tempo". Set a tempo from the dialog.')
H2('A8. CC Map, Controllers and the MIDI Log (5 minutes)')
S('Click <b>MIDI Log</b> and set <b>Status checks</b> to Hidden.',
  'Click <b>Controllers</b> and move a fader: the log shows "OUT CC 17 = ..." lines.',
  'Click <b>CC Map</b>: your own numbers are shown in blue; clashes in red. Click <b>MIDI CC troubleshooting...</b> to see the knobs and sliders with their unit lines.')
H2('A9. Options and Axe-Edit (5 minutes)')
S('Click <b>Options</b> and look through the settings - for example the click-stop step of the volume sliders.',
  'Click <b>Axe-Edit</b>. Read the explanation, start the editor, load a preset in it, then press <b>Refresh</b> in the Workbench.',
  'Close Axe-Edit: the Workbench follows the unit again by itself.')

# ============================================================================ Appendix B functions
story.append(PageBreak())
H1('Appendix B - Settings function list')
P('Every Axe-Fx II function in the Settings window, in the same order. MIDI = Yes means the Workbench can do it for you; App window opens a Workbench window.')
rows = [['#', 'Function', 'Category', 'Front panel', 'MIDI']]
for line in open(os.path.join(HERE, 'functions.tsv'), encoding='utf-8'):
    f = line.rstrip('\n').split('\t')
    if len(f) == 5:
        rows.append([f[0], f[1].replace('&', '&amp;').replace('<', '&lt;'), f[2].replace('&', '&amp;'), f[3].replace('&', '&amp;').replace('>', '&gt;'), f[4]])
table(rows, [0.35 * inch, 2.55 * inch, 1.3 * inch, 1.8 * inch, 0.5 * inch])

# ============================================================================ Appendix C gen 3 beta
story.append(PageBreak())
H1('Appendix C - Gen 3 beta testing')
P('Fractal documents the Axe-Fx III\'s MIDI commands, but some things only a real unit can answer. Until testers have confirmed every '
  'row below, Axe-Fx III, FM9 and FM3 support stays marked beta.')
table([['Item', 'What Sierpinski assumes', 'How a tester checks it'],
       ['FM3 and FM9 model IDs', 'Fractal\'s document covers only the Axe-Fx III (0x10). Assumed FM3 = 0x11, FM9 = 0x12.', 'The self-test reports the model byte the unit answers with.'],
       ['FM3 / FM9 answer the Axe-Fx III commands', 'Bypass, channel, scene, preset and scene names, looper, tap tempo, tuner, status dump and tempo work the same way.', 'The self-test sends each command and records the reply.'],
       ['Scene numbering', 'Scenes count 0-7 (0 = scene 1).', 'Select scene 1 from the Workbench - the unit must show scene 1.'],
       ['Safe timing', 'Gen 3 is checked about every 1.2 s; preset names read without missed replies.', 'Read all presets; the self-test times each reply.'],
       ['Tuner and tempo over 5-pin', 'With Send Realtime Sysex = ON the unit streams tuner and tempo over 5-pin MIDI OUT.', 'Turn the tuner on and play: the tuner bar moves and the tempo light flashes.'],
       ['Block names and newer blocks', 'Block IDs from Fractal\'s Axe-Fx III list. Newer blocks (NAM Player, IR Player, Dynamic Distortion, Multiplexer, Scene MIDI) aren\'t in it yet and may show as "Block nnn".', 'Compare the Workbench\'s blocks with the unit\'s grid; report any "Block nnn".'],
       ['Blocks of every preset', 'The first-start sync (or Read blocks too) loads each preset and reads its blocks.', 'Sync, then compare a few presets\' Blocks with the unit.'],
       ['Factory preset list', 'Names from the Fractal wiki for the stated firmware; amps and expected blocks from its notes.', 'Share the factory preset list after the sync (section 13).']],
      [1.45 * inch, 2.75 * inch, 2.3 * inch])
H2('The Gen 3 self-test')
S('Use a preset you don\'t mind changing and STORE any edits - the test switches scenes and toggles blocks, then puts them back.',
  'Connect the unit by 5-pin MIDI (IN and OUT) and set Send Realtime Sysex = ON. Close the Fractal editor if it uses USB.',
  'Choose the Model (or Detect), open <b>MIDI Log</b>, press <b>Gen 3 Self-Test</b>, then Start Test, and follow the prompts (about a minute).',
  'Press <b>Save Report</b> and email it to Sierra Digital Audio (Contact page on sierradigitalaudio.com) with your unit model and firmware.')
P('<b>Sharing the factory preset list</b> after the first-start sync (section 13) is a second, very welcome report: it fills in the real blocks '
  'of the factory presets for every future user, and also confirms that your unit answers the Gen 3 commands.')

# ============================================================================ Appendix D windows midi
H1('Appendix D - Windows 10 and Windows 11 MIDI notes')
P('Whether two programs - say Sierpinski Workbench and your Fractal editor - can use the same MIDI port at the same time is decided by '
  'Windows, not by Sierpinski or Fractal.')
B('<b>One program per port</b> (Windows 10, and Windows 11 without Windows MIDI Services): Windows\' standard USB MIDI driver lets only one program '
  'open a MIDI port at a time. The Workbench then says the port is in use and, with the Axe-Edit button, takes turns with the editor.',
  '<b>Shared ports</b> (Windows 11 with Windows MIDI Services): every MIDI port can be opened by several programs. It arrives through Windows Update '
  'on Windows 11 24H2 and 25H2; there is no switch to turn it on. A MIDI device plugged in after a MIDI program has started may not work - plug in '
  'and switch on your gear before starting the Workbench.',
  '<b>Is it on my PC?</b> Press Win+R, type services.msc, and look for <b>Windows MIDI Service</b>. Or connect Axe-Edit over USB and then the '
  'Workbench on the same port: if both connect, your PC shares ports.',
  'The Fractal editors pause themselves for a few seconds when something else changes the preset, then resume. Constant checking from another '
  'program would keep them paused - which is why the Workbench stops its status checks while the editor is open on a shared port.',
  'Whatever your computer: don\'t read all your presets while editing in the Fractal editor, and if you also use Sierpinski VST3, keep the unit\'s ports disabled in your DAW.')
P('<i>Fractal Audio, Axe-Fx, FM9, FM3 and Axe-Edit are trademarks of Fractal Audio Systems. Sierra Digital Audio is not affiliated with or endorsed '
  'by Fractal Audio Systems. Other product names mentioned (for example amplifier makers) are trademarks of their owners and are used only to describe '
  'the factory presets.</i>', small)

doc = HelpDoc(OUT)
doc.multiBuild(story)
print('built', OUT)
