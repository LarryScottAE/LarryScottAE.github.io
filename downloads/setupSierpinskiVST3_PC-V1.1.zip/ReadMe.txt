Sierpinski VST3 1.1 for Windows 10 and 11
Sierra Digital Audio - www.SierraDigitalAudio.com

INSTALL
1. Unzip setupSierpinskiVST3_PC-V1.1.zip.
2. Copy the Sierpinski.vst3 folder to   C:\Program Files\Common Files\VST3
   (replace an older Sierpinski.vst3 if Windows asks).
3. Install Fractal Audio's USB driver for your unit if you connect by USB.
4. Start your DAW and let it rescan plugins. Insert Sierpinski on your guitar
   track - it is an effect (audio passes through unchanged).

BEFORE YOU START
- Turn off the Fractal unit's MIDI ports in your DAW's MIDI settings -
  Sierpinski opens them itself. Reaper: Options > Preferences > MIDI Inputs /
  MIDI Outputs, right-click the port, Disable.
- Then open Settings > Setup in the plugin and go through its six steps.
- The full manual: the Help button in the plugin.

Axe-Fx, FM9, FM3, Axe-Edit and Fractal Audio are trademarks of Fractal Audio
Systems. Sierra Digital Audio is not affiliated with Fractal Audio Systems.
VST is a registered trademark of Steinberg Media Technologies GmbH.
