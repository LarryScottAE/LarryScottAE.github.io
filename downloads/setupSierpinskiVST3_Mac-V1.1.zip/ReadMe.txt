Sierpinski VST3 / AU 1.1 for the Mac (Apple Silicon and Intel, macOS 12 Monterey or later)
Sierra Digital Audio - www.SierraDigitalAudio.com

INSTALL
1. Double-click setupSierpinskiVST3_Mac-V1.1.zip (if your browser didn't unzip it).
2. Open Finder > Go > Go to Folder... and type:   ~/Library/Audio/Plug-Ins
3. Drag Sierpinski.component into the Components folder (Logic Pro, GarageBand
   and other AU hosts) and Sierpinski.vst3 into the VST3 folder (Reaper,
   Cubase, Studio One, Ableton Live ...). Create the folder if it is missing.
4. The plugin is not from the App Store, so macOS blocks it the first time.
   Open Terminal (Applications > Utilities) and paste these two lines:

   xattr -cr ~/Library/Audio/Plug-Ins/Components/Sierpinski.component
   xattr -cr ~/Library/Audio/Plug-Ins/VST3/Sierpinski.vst3

5. Restart your DAW and let it rescan plugins. Insert Sierpinski on your guitar
   track - it is an effect (audio passes through unchanged).

BEFORE YOU START
- Turn off the Fractal unit's MIDI ports in your DAW's MIDI settings -
  Sierpinski opens them itself.
- Then open Settings > Setup in the plugin and go through its six steps.
- The full manual: the Help button in the plugin.

Axe-Fx, FM9, FM3, Axe-Edit and Fractal Audio are trademarks of Fractal Audio
Systems. Sierra Digital Audio is not affiliated with Fractal Audio Systems.
VST is a registered trademark of Steinberg Media Technologies GmbH.
